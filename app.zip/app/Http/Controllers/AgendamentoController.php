<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class AgendamentoController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function getAgendamento(){
        return response()->json([
            ["id_agendamento" => 1, "data_agendamento" => "06/04", "hora_agendamento" => "09:00", "nome_profissional" => "Germano", "nome_cliente" =>"Bruno"],
            ["id_agendamento" => 2, "data_agendamento" => "10/04", "hora_agendamento" => "10:00", "nome_profissional" => "Hanna", "nome_cliente" => "Josue"],
            ["id_agendamento" => 3, "data_agendamento" => "13/04", "hora_agendamento" => "11:00", "nome_profissional" => "Nathy", "nome_cliente" => "Matheus"],
            ["id_agendamento" => 4, "data_agendamento" => "16/04", "hora_agendamento" => "12:00", "nome_profissional" => "Caue", "nome_cliente" => "Ludi"],
            ["id_agendamento" => 5, "data_agendamento" => "22/04", "hora_agendamento" => "14:00", "nome_profissional" => "Germano", "nome_cliente" => "Flavia"], 
            ["id_agendamento" => 6, "data_agendamento" => "24/04", "hora_agendamento" => "9:00", "nome_profissional" => "Nathy", "nome_cliente" => "Bruno"],
            ["id_agendamento" => 7, "data_agendamento" => "26/04", "hora_agendamento" => "10:00", "nome_profissional" => "Caue", "nome_cliente" => "Ludi"],
            ["id_agendamento" => 8, "data_agendamento" => "28/04", "hora_agendamento" => "11:00", "nome_profissional" => "Hanna", "nome_cliente" => "Matheus"],
            ["id_agendamento" => 9, "data_agendamento" => "29/04", "hora_agendamento" => "12:00", "nome_profissional" => "Germano", "nome_cliente" => "Josue"],
            ["id_agendamento" => 10, "data_agendamento" => "30/04", "hora_agendamento" => "14:00", "nome_profissional" => "Nathy", "nome_cliente" => "Flavia"]
            


        ]);
    }
}
