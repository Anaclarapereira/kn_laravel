<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class ServicoController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function getServico(){
        return response()->json([
            ["id" => 1, "nome_servico" => "barba"],
            ["id" => 2, "nome_servico" => "corte"],
            ["id" => 3, "nome_servico" => "barba e corte"],
            ["id" => 4, "nome_servico" => "reflexo"],
            ["id" => 5, "nome_servico" => "pigmentação"],
            ["id" => 6, "nome_servico" => "nevou"],
            ["id" => 7, "nome_servico" => "pezinho"],
            ["id" => 8, "nome_servico" => "sobrancelha"],
            ["id" => 9, "nome_servico" => ""],
            ["id" => 10, "nome_servico" => ""]
            


        ]);
    }
}

//id_agendamento | data_agendamento |  hora_agendamento | nome_profissional | nome_cliente 
