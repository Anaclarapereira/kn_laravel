<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ServicoController;
use App\Http\Controllers\AgendamentoController;


Route::get('usuarios', [UserController::class, 'getUsuarios']);
Route::get('servicos', [ServicoController::class, 'getServico']);
Route::get('agendamentos',[AgendamentoController::class, 'getAgendamento']);